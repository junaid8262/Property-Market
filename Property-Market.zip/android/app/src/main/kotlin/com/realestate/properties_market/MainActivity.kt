package com.realestate.properties_market

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
