import 'package:flutter/cupertino.dart';

const primaryColor = Color(0xFF0247af);
const backgroundColorLight = Color(0xFFfcdeb3);
//const adminId="GSExrT5IUrfVmg9bY9kZcayclFl2";
const adminId="Ikpm3S7725h8UFeFJ8shhTB0e6F2"; //temp admin
const serverToken="AAAAEw4em9g:APA91bGrMl-LZ_gVm1AETZqjl0k4eKAKt16Ilzsp-ngfQuypNqvXmK8Y8FyYMw-N9t9FYGYgS_HFjblGk1bH0rIThyShDTsStDMSrkkRF4s2QLSn3_4pmcU0RcuKvSGczIDFHPVjAdph";
const primaryColorDark = Color(0xFF2f3b47);
final RegExp emailValidatorRegExp =
RegExp(r"^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
const String kEmailNullError = "Please Enter your email";
const String kInvalidEmailError = "Please Enter Valid Email";
const String kPassNullError = "Please Enter your password";
const String kShortPassError = "Password is too short";
const String kMatchPassError = "Passwords don't match";
const String kNamelNullError = "Please Enter your name";
const String kPhoneNumberNullError = "Please Enter your phone number";
const String kAddressNullError = "Please Enter your address";
const String url="https://www.freeprivacypolicy.com/live/b36b4963-0837-491b-ac0b-dadb078b2120";
const String androidInterstitialVideo="ca-app-pub-9395198588563221/8384182785";
const String androidAdmobBanner="ca-app-pub-9395198588563221/8108016460";/*
const String androidFanBanner="4072676972810543_4084550341623206";
const String androidFanInterstitialVideo="4072676972810543_4084573791620861";*/
const String iosAdmobBanner="ca-app-pub-9395198588563221/9480328959";
const String iosAdmobInterstitialVideo="ca-app-pub-9395198588563221/8384182785";


