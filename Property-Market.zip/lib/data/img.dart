/*Load image from folder assets/images/
 */
class Img {
  static String get(String name){
    return 'assets/images/'+name;
  }
}
