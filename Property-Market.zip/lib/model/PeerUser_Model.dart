class PeerUser
{
  String userId , username , email , profilePic , id ;

  PeerUser(this.userId, this.username, this.email, this.profilePic , this.id);
}