class UserModel
{
  String token , username , email , profilePic , id ;

  UserModel(this.token, this.username, this.email, this.profilePic , this.id);
}