class NewsModel{
  String id,image,details,details_ar,date;

  NewsModel(this.id, this.image, this.details, this.details_ar, this.date);
}