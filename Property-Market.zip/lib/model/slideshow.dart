class SlideShow{
  String id,image,language,date;

  SlideShow(this.id, this.image,this.language,this.date);
}