class MyInformation{
  String email,phone;

  MyInformation(this.email, this.phone);

}