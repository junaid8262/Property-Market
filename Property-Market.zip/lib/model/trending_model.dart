class TrendingModel{
  String id,video,icon,title,title_ar,details,details_ar,date;

  TrendingModel(this.id, this.video,this.icon, this.title, this.title_ar, this.details,
      this.details_ar, this.date);
}