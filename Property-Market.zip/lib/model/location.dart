class LocationModel{
  String id,name,name_ar;

  LocationModel(this.id, this.name,this.name_ar);

}