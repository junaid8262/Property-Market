class UserNotificationModel
{
  String userid , city , country , area ,type ,propertyCategory,city_ar , country_ar , area_ar ,type_ar ,propertyCategory_ar ,notificationId ;

  UserNotificationModel(
      this.userid,
      this.city,
      this.country,
      this.area,
      this.type,
      this.propertyCategory,
      this.city_ar,
      this.country_ar,
      this.area_ar,
      this.type_ar,
      this.propertyCategory_ar,
      this.notificationId);
}