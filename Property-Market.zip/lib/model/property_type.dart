class PropertyType{
  String id,name,name_ar;

  PropertyType(this.id,this.name, this.name_ar);
}