import 'dart:io';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:propertymarket/values/constants.dart';

class PrivacyWebView extends StatefulWidget {
  @override
  _PrivacyWebViewState createState() => _PrivacyWebViewState();
}

class _PrivacyWebViewState extends State<PrivacyWebView> {


  @override
  Widget build(BuildContext context) {
    return Container();
  }
}